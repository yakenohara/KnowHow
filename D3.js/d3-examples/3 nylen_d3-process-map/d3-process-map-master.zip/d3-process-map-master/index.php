<?php
require_once 'common.php';
header("Location: graph.php$dataset_qs");
?>
